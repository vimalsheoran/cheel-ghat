const moment = require("moment-timezone");
moment.tz.add("Asia/Kolkata|HMT +0630 IST|-5R.k -6u -5u|01212|-18LFR.k 1unn.k HB0 7zX0|15e6");
moment.tz.setDefault("Asia/Kolkata");

function MaintainanceHelper(){}

MaintainanceHelper.prototype.updateRecord = async function(data, modeFlag, userId){
	try {
		data["mode"] = modeFlag;
		data["updatedBy"] = userId;
		let timeNow;
		timeNow = modeFlag === "resolved" ? moment().format("YYYY-MM-DD HH:mm:ss") : undefined;
		await MaintainanceHistory.update(
			{ "poleId": data.poleId },
			{ "mode": modeFlag, "updatedBy": userId, "lastMaintain": timeNow }
		)
	} catch (err){
		console.log(err);
		throw err;
	}
}

module.exports = {
	"MaintainanceHelper": MaintainanceHelper
}