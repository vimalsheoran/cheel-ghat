module.exports = {
	"attributes": {
		"ccmsId": {
			"type": "string"
		},
		"poleIds": {
			"type": "json",
			"columnType": "array"
		},
		"loc": {
			"type": "string"
		}
	}
}