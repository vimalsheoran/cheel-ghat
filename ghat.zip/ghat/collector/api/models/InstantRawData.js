module.exports = {
	"attributes": { 
	   	"ccms_id": { 
	   		"type": 'string' 
	   	},
	    "timestamp": { 
	    	"type": 'string' 
	    },
	    "active_power_kw": { 
	    	"type": 'string' 
	    },
	    "apparent_power_kva": { 
	    	"type": 'string' 
	    },
	    "current_r_(a)": { 
	    	"type": 'string' 
	    },
	    'current_y_(a)': { 
	    	"type": 'string' 
	    },
	    'current_b_(a)': { "type": 'string' },
	    'voltage_r_(v)': { "type": 'string' },
	    'voltage_y_(v)': { "type": 'string' },
	    'voltage_b_(v)': { "type": 'string' },
	    "total_pf": { "type": 'string' },
	    'frequency_(hz)': { "type": 'string' },
	    "md_kva": { "type": 'string' },
	    "md_kw": { "type": 'string' },
	    "load_relay_status_r": { "type": 'string' },
	    "load_relay_status_y": { "type": 'string' },
	    "load_relay_status_b": { "type": 'string' },
	    "r_phase_kw": { "type": 'string' },
	    "y_phase_kw": { "type": 'string' },
	    "b_phase_kw": { "type": 'string' },
	    "active_mode": { "type": 'string' },
	    "total_active_energy": { "type": 'string' },
	    "total_apparent_energy": { "type": 'string' },
	    "current_day_kwh": { "type": 'string' },
	    "current_day_kvah": { "type": 'string' },
	    'power_on_time(hrs)': { "type": 'string' },
	    'relay_on_time(hrs)': { "type": 'string' },
	    "current_day_meter_on_period": { "type": 'string' },
	    "current_day_relay_on_period": { "type": 'string' } }
}