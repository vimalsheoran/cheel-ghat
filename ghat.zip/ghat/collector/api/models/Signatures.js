module.exports = {
	"attributes": {
		"modelNo": {
			"type": "string"
		},
		"vendor": {
			"type": "string"
		},
		"rating": {
			"type": "string"
		},
		"expectedLife": {
			"type": "string"
		}
	}
}