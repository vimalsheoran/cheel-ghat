module.exports = {
	"attributes": {
		"ccms_id": {
			"type": "string"
		},
		"timestamp": {
			"type": "string"
		},
		"ccms_kwh": {
			"type": "string"
		},
		"grid_kvah": {
			"type": "string"
		},
		"meter_on_duration": {
			"type": "string"
		},
		"on_load_duration": {
			"type": "string"
		},
		"expected_kwh": {
			"type": "string"
		}
	}
}