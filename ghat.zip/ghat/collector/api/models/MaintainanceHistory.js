module.exports = {
	"attributes": {
		"poleId": {
			"type": "string"
		},
		"loc": {
			"type": "string"
		},
		"ccms": {
			"type": "string"
		},
		"phase": {
			"type": "string"
		},
		"lastMaintain": {
			"type": "string"
		},
		"mode": {
			"type": "string"
		},
		"updatedBy": {
			"type": "string"
		},
		"currLifeTime": {
			"type": "string"
		},
		"runtime": {
			"type": "string"
		}
	}
}