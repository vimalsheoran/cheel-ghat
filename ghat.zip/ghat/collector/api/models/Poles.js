module.exports = {
	"attributes": {
		"poleId": {
			"type": "string"
		},
		"loc": {
			"type": "string"
		},
		"ccmsId": {
			"type": "string"
		},
		"phase": {
			"type": "string"
		},
		"signature": {
			"type": "string"
		}
	}
}