const MaintainanceHelper = require("../MaintainanceHelper").MaintainanceHelper;
let maintainanceHelper = new MaintainanceHelper();

module.exports = {
	
	"registerComplaint": async (req, res) => {
		try {
			let data = req.body.data;
			if(!data.poleId || !data.loc || !data.ccms || !data.phase)
				return res.badRequest("Bad QR Configuration.");
			let existingVal = await MaintainanceHistory.findOne({"poleId": data.poleId});
			if(existingVal) return res.ok("Complaint already registered.");
			data["mode"] = "complaint";
			await MaintainanceHistory.create(data);
			return res.ok("Complaint registered successfully.");
		} catch (err){
			console.log(err);
			return res.serverError("Oops! Something went wrong.");
		}
	},

	"fetchComplaint": async (req, res) => {
		try {
			let {data, userFlag} = req.body;
			if(!userFlag || userFlag !== "technician")
				return res.forbidden();
			let existingVal = await MaintainanceHistory.findOne({"poleId": data.poleId});
			if(!existingVal) return res.ok("No complaint lodged for this device.");
			return res.ok(existingVal);
		} catch (err){
			console.log(err);
			return res.serverError("Oops! Something went wrong.");
		}
	},

	"updateComplaint": async (req, res) => {
		try {
			let {data, userRole, userId} = req.body;
			if(!userRole || userRole !== "technician")
				return res.forbidden();
			if(!data.poleId || !data.modeFlag || !userId)
				return res.badRequest("Missing parameters in the request.");
			await maintainanceHelper.updateRecord(data, data.modeFlag, userId);
			return res.ok("Succesfully updated complaint.");
		} catch (err){
			console.log(err);
			return res.serverError("Oops! Something went wrong.");
		}
	},

	"fetchCcmsAggregation": async (req, res) => {
		try {
			let {ccmsId, phase} = req.allParams();
			if(!ccmsId || !phase) return res.badRequest("Insufficient parameters.");
			let ccmsValues = await Ccms.find({ccmsId});
			let aggrData = [];
			for(let ccmsValue of ccmsValues){
				let poleData = await MaintainanceHistory.find({"poleId": ccmsValue.poleId, "phase": phase});
				aggrData = [...aggrData, ...poleData];
			}
			console.log(aggrData);
			return res.ok(aggrData);
		} catch (err){
			console.log(err);
			return res.serverError("Oops! Something went wrong.");
		}
	},

	"fakeData": async (req, res) => {
		let data = [
			{
				"ccmsId": "sjpl",
				"poleIds": ["a", "b", "c", "d", "e"]
			}			
		];
		await Ccms.createEach(data);
		return res.ok("Done!");
	},

	"generateInsights": async (req, res) => {
		
	}
}

// {
// 				"poleId": "a",
// 				"lastMaintain": "2019-05-24 00:00:00",
// 				"currLifeTime": "10000",
// 				"runtime": "5000",
// 				"phase": "r"
// 			},
// 			{
// 				"poleId": "b",
// 				"lastMaintain": "2019-05-01 00:00:00",
// 				"currLifeTime": "20000",
// 				"runtime": "15000",
// 				"phase": "y" 
// 			},
// 			{
// 				"poleId": "c",
// 				"lastMaintain": "2017-05-01 00:00:00",
// 				"currLifeTime": "15000",
// 				"runtime": "10000",
// 				"phase": "b"
// 			},
// 			{
// 				"poleId": "d",
// 				"lastMaintain": "2018-05-01 00:00:00",
// 				"currLifeTime": "10000",
// 				"runtime": "5000",
// 				"phase": "b"
// 			},
// 			{
// 				"poleId": "e",
// 				"lastMaintain": "2019-01-01 00:00:00",
// 				"currLifeTime": "7500",
// 				"runtime": "2500",
// 				"phase": "y"
// 			}
