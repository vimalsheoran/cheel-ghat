const XLSX = require("xlsx");
const fs = require("fs");

const sanitizeJsonDataKeys = async (jsonData) => {
	let keys = Object.keys(jsonData[0]);
	let keyMap = {}, sanitizedData = [];
	for(let key of keys){
		let newKey = key.toLowerCase().replace(/ /g, "_");
		keyMap[newKey] = key;
	}
	for(let data of jsonData){
		let newData = {};
		for(let newKey of Object.keys(keyMap)){
			newData[newKey] = data[keyMap[newKey]];
		}
		sanitizedData.push(newData);
	}
	return sanitizedData;
}

const addToDatabase = async (data,type) => {
	try {
		if(type === "dailyconsumption"){
			await DailyConsumption.create(data);
		}
		else if(type === "rawdata") {
			await InstantRawData.create(data);
		}
	} catch (err){
		console.log(err);
		throw err;
	}
}

module.exports = {
	
	"testController": async (req, res) => {
		return res.ok("Ok the setup is working.");
	},

	"handleUpload": async (req, res) => {
		try {
			let fileType = req.allParams().fileType;
			if(!req.file("uploadFile")) res.badRequest("No file field provided.");
			if(req.method === "GET")
				return res.ok("Invalid Method on the route, use POST.");
			let uploadFile = req.file("uploadFile");
			uploadFile.upload(async (err, file) => {
				if(err)
					return res.serverError("Something went wrong!");
				let xlFile = XLSX.readFileSync(file[0].fd);
				let sheetRef = Object.keys(xlFile.Sheets)[0];
				let sheet = xlFile.Sheets[sheetRef];
				let dirtyData = await XLSX.utils.sheet_to_json(sheet);
				let cleanData = await sanitizeJsonDataKeys(dirtyData);
				for(let data of cleanData){
					await addToDatabase(data, fileType);
				}
				return res.ok("Successfully uploaded data!");
			});
		} catch (err){
			console.log(err);
			return res.serverError("Something went wrong!");
		}
	}
}