module.exports = {

	"uploadPoleConfiguration": async (req, res) => {
		try {
			let {poleId, loc, ccmsId, phase, signature} = req.body;
			let feedback;
			if(!poleId)
				return res.badRequest("Missing parameters for configuration.");
			let existingConfiguration = await Poles.findOne({poleId});
			if(!existingConfiguration){
				if(!loc || !ccmsId || !phase || !signature)
					return res.badRequest("Missing parameters for configuration.");
				await Poles.create({poleId, loc, ccmsId, phase, signature});
				feedback = "Successfully created pole configuration.";
			} else {
				await Poles.update({poleId}, {signature});
				feedback = "Successfully updated pole configuration.";
			}
			return res.ok(feedback)
		} catch (err){
			console.log(err);
			throw err;
		}
	},

	"uploadCcmsConfiguration": async (req, res) => {
		try {
			let {ccmsId, loc, poleIds} = req.body;
			if(!ccmsId) return res.badRequest("Missing parameters for configuration.");
			let existingConfiguration = await Ccms.findOne({ccmsId});
			if(!existingConfiguration){
				if(!loc || !poleIds)
					return res.badRequest("Missing parameters for configuration.");
				await Ccms.create({ccmsId, loc, poleIds});
			} else {
				let existingPoleIds = existingConfiguration.poleIds;
				poleIds = [...existingPoleIds, ...poleIds];
				await Ccms.update({ccmsId}, {poleIds});
			}
			return res.ok("Succesfull.");
		} catch (err){
			console.log(err);
			throw err;
		}
	},

	"uploadSignatureInformation": async (req, res) => {
		try {
			let {modelNo, vendor, rating, expectedLife} = req.body;
			if(!modelNo || !vendor || !rating || !expectedLife)
				return res.badRequest("Missing parameters for configuration.");
			let existingConfiguration = await Signatures.findOne({id, vendor, rating, expectedLife});
			if(existingConfiguration) return res.ok("Signature already configured.");
			await Signatures.create({modelNo, vendor, rating, expectedLife});
			return res.ok("Successfully registered signature.");
		} catch (err){
			console.log(err);
			throw err;
		}
	}
}