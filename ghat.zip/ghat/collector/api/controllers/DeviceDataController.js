module.exports = {

	"getData": async (req, res) => {
		try {
			let {ccmsId, startTime, endTime} = req.allParams();
			if(!ccmsId || !startTime || !endTime)
				return res.badRequest("Missing parameters in the request.");
			const query = {
				"ccms_id": ccmsId,
				"timestamp": {
					">=": endTime,
					"<": startTime
				}
			};
			let data = await InstantRawData.find(query).sort([{"timestamp": "DESC"}]);
			return res.ok(data);
		} catch (err){
			console.log(err);
			return res.serverError("Oops! Something went wrong.");
		}
	}
}