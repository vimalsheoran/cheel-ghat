import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit  {
  // google maps zoom level
  zoom: number = 16;
  log = false;
  complain = false;
  technician = true;
  markerColor = true;
  ccmsObj;
  id = 'ccms-24';
  mode = 'Under Maintenance';
  maintenance = "20th January, 2019"
  address = 'CCMS Gurgaon Cohive';
  constructor(public dialog: MatDialog) {
    if (navigator)
    {
    navigator.geolocation.getCurrentPosition( pos => {
        this.lng = 77.090908;
        this.lat =  28.512486;
      });
    }
  }
  ngOnInit() {
    // console.log('route',this.route);
    // const poleId = this.route.snapshot.paramMap.get('poleId');
    // const loc =  this.route.snapshot.paramMap.get('loc');
    // const ccms = this.route.snapshot.paramMap.get('ccms');
    // const phase = this.route.snapshot.paramMap.get('phase');
    // this.ccmsObj = {
    //   poleId,
    //   loc,
    //   ccms,
    //   phase,
    // };
    // console.log('init data qr', this.ccmsObj);
  }
  // initial center position for the map
  lat: number = 51.673858;
  lng: number = 7.815982;

  clickedMarker(label: string, index: number) {
    console.log(`clicked the marker: ${label || index}`)
  }
  openLoginDialog(){
    this.log = true;
  }
  openComplainDialog(){
    this.complain = true;
    this.technician = true;
  }
  login(){
    this.log= false;
    this.technician = false;
  }
  complainHere(){
    this.complain = false;
    this.markerColor = true;
  }
  resolveIssue(){
this.markerColor = false;
  }
  markers: marker[] = [
    {
        lat: 28.512486,
        lng: 77.090908,
        label: 'CCMS Gurgaon Cohive',
        draggable: true
      }
  ]
  
}
interface marker {
	lat: number;
	lng: number;
	label?: string;
	draggable: boolean;
}


